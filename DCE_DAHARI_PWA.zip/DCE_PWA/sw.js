const CACHE = 'dce-dahari-v1';
const ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './images/DAHARI.png',
  './images/restrictionu.png',
  './images/restriction_1.jpg',
  './images/restriction_2.jpg',
  './images/sans_restriction.jpg',
  './images/pas_pop.jpg',
  './images/2_persone.png',
  './images/personnes_2.jpg',
  './images/plusieurs_p.png',
  './images/BLANCC.jpg',
  './images/frigo.jpg',
  './images/sechages.jpg',
  './images/DCP.jpg',
  './images/sans_pop.jpg',
  './images/locoaux.jpg',
  './images/femmes1.jpg',
  './images/reso.png',
  './images/cost_10.jpg',
  './images/cost_20.jpg',
  './images/cost_30.jpg',
  './images/cost_50.jpg'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(cache => {
      return Promise.allSettled(
        ASSETS.map(url => cache.add(url).catch(() => {}))
      );
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(cached => {
      if (cached) return cached;
      return fetch(e.request).then(response => {
        if (response && response.status === 200) {
          const clone = response.clone();
          caches.open(CACHE).then(cache => cache.put(e.request, clone));
        }
        return response;
      }).catch(() => cached);
    })
  );
});
