# DCE DAHARI — Application Web Progressive (PWA)
**Fonctionne 100% hors-ligne sur tablettes Android**

---

## Structure
```
DCE_DAHARI_PWA/
├── index.html      ← Application complète (UI + logique + design intégré)
├── sw.js           ← Service Worker (cache offline)
├── manifest.json   ← Manifest PWA (installation Android)
└── images/         ← Vos images (à copier ici)
    ├── DAHARI.png
    ├── restriction_1.jpg
    └── ...
```

---

## Déploiement sur GitHub Pages (une seule fois au bureau)

### 1. Créer le dépôt GitHub
- github.com → New repository → `DCE-DAHARI-PWA` → **Public** (obligatoire pour GitHub Pages)

### 2. Uploader les fichiers
```bash
git init
git add .
git commit -m "DCE DAHARI PWA"
git remote add origin https://github.com/VOTRE_COMPTE/DCE-DAHARI-PWA.git
git push -u origin main
```

### 3. Activer GitHub Pages
- Dépôt → Settings → Pages → Source : **main / root** → Save
- URL obtenue : `https://VOTRE_COMPTE.github.io/DCE-DAHARI-PWA/`

---

## Installation sur tablette Android (une seule fois par tablette, avec WiFi)

1. Ouvrir **Chrome** sur la tablette
2. Aller sur l'URL GitHub Pages
3. Attendre que la page charge complètement (quelques secondes)
4. Menu Chrome (⋮) → **"Ajouter à l'écran d'accueil"** → Installer
5. Une icône DCE DAHARI apparaît sur l'écran d'accueil

✅ **Ensuite, l'app fonctionne sans aucune connexion internet.**

---

## Fonctionnement terrain

- Chaque pêcheur répond sur une tablette
- Les données sont sauvegardées automatiquement dans la tablette (localStorage)
- Plusieurs pêcheurs peuvent répondre sur la même tablette (les données s'accumulent)

---

## Récupération des données (retour au bureau)

1. Ouvrir l'app sur la tablette
2. Aller jusqu'à l'écran "Merci"
3. Appuyer sur **"Exporter les données (CSV)"**
4. Le fichier `DCE_DAHARI_YYYY-MM-DD.csv` se télécharge
5. Copier le CSV vers votre laptop pour analyse

---

## Mise à jour du design (si nécessaire)

Si vous régénérez le design en R avec `idefix`, exportez-le en JSON :

```r
# Dans R, après avoir généré pool_complet :
rows_json <- apply(pool_complet, 1, function(r) {
  sprintf('{"s":%s,"a":%s,"fr":%s,"ps":%s,"ni":%s,"eq":%s,"sc":%s,"lr":"%s","ls":"%s","li":"%s","le":"%s","lc":"%s"}',
    r["ensemble_choix"], r["alternative"],
    r["fishing_restrictions"], r["participation_surveillance"],
    r["new_infrastructure"], r["equity"], r["surveillance_cost"],
    r["etiquette_restrictions"], r["etiquette_surveillance"],
    r["etiquette_infrastructure"], r["etiquette_equite"], r["etiquette_cost"])
})
json <- paste0("[", paste(rows_json, collapse=","), "]")
writeLines(json, "design_32sets.json")
```

Puis remplacer dans `index.html` la ligne :
```javascript
const POOL = [...];   // ← coller ici le contenu de design_32sets.json
```

---

## Images requises dans `images/`

| Fichier | Attribut |
|---|---|
| `restrictionu.png`, `restriction_1.jpg`, `restriction_2.jpg`, `sans_restriction.jpg` | Restrictions pêche |
| `pas_pop.jpg`, `2_persone.png`, `personnes_2.jpg`, `plusieurs_p.png` | Surveillance |
| `BLANCC.jpg`, `frigo.jpg`, `sechages.jpg`, `DCP.jpg` | Infrastructure |
| `sans_pop.jpg`, `locoaux.jpg`, `femmes1.jpg`, `reso.png` | Équité |
| `cost_10.jpg`, `cost_20.jpg`, `cost_30.jpg`, `cost_50.jpg` | Coût |
| `DAHARI.png` | Logo |
